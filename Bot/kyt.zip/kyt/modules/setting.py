from kyt import *

@bot.on(events.CallbackQuery(data=b'reboot'))
async def rebooot(event):
	async def rebooot_(event):
		cmd = f'reboot'
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Restart Service Server...`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		subprocess.check_output(cmd, shell=True)
		await event.edit(f"""
**» REBOOT SERVER**
**» 🤖@newbie_store242**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await rebooot_(event)
	else:
		await event.answer("Access Denied",alert=True)


@bot.on(events.CallbackQuery(data=b'resx'))
async def resx(event):
	async def resx_(event):
		cmd = f'systemctl restart xray | systemctl restart nginx | systemctl restart haproxy | systemctl restart server | systemctl restart udp-custom | systemctl restart noobzvpns | systemctl restart client'
		subprocess.check_output(cmd, shell=True)
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Restart Service Server...`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(1)
		await event.edit(f"""
```Processing... 100%\n█████████████████████████ ```
**» Restarting Service Done**
**» 🤖@newbie_store242**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await resx_(event)
	else:
		await event.answer("Access Denied",alert=True)
		
@bot.on(events.CallbackQuery(data=b'speedtest'))
async def speedtest(event):
	async def speedtest_(event):
		cmd = 'speedtest-cli --share'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		time.sleep(0)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		await event.respond(f"""
**
{z}
**
**» 🤖@newbie_store242**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await speedtest_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'backup'))
async def backup(event):
	async def backup_(event):
		await asyncio.sleep(1)
		await event.edit("`Wait.. Processing Backup`")
		cmd = 'backup'
		try:
			raw_output = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except Exception:
			await event.respond("**Not Exist**")
		else:
			# 1. Hapus semua kode warna ANSI
			ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
			a = ansi_escape.sub('', raw_output)

			# 2. Extract data dengan Regex
			file_id  = re.search(r"ID FILE\s*:\s*(\S+)", a)
			in_date  = re.search(r"IN DATE\s*:\s*(\S+)", a)
			domain   = re.search(r"DOMAIN\s*:\s*(\S+)", a)
			ip_vps   = re.search(r"IP VPS\s*:\s*(\S+)", a)
			password = re.search(r"PASS\s*:\s*(\S+)", a)

			id_val   = file_id.group(1) if file_id else "-"
			date_val = in_date.group(1) if in_date else "-"
			dom_val  = domain.group(1) if domain else "-"
			ip_val   = ip_vps.group(1) if ip_vps else "-"
			pass_val = password.group(1) if password else "-"

			msg = f"""
**» 🚀 BACKUP VPS SUCCESS**
━━━━━━━━━━━━━━━━━━━━━
**» 📁 ID FILE  :** `{id_val}`
**» 📅 IN DATE  :** `{date_val}`
**» 🌐 DOMAIN   :** `{dom_val}`
**» 💻 IP VPS   :** `{ip_val}`
**» 🔑 PASS     :** `{pass_val}`
━━━━━━━━━━━━━━━━━━━━━
**» 🤖 @newbie_store242**
"""
			await event.respond(msg)

	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await backup_(event)
	else:
		await event.answer("Akses Ditolak", alert=True)
        
import asyncio
import subprocess
import os

@bot.on(events.CallbackQuery(data=b'restore'))
async def restore(event):
	async def restore_(event):
		try:
			# 1. Minta ID Backup dari user
			async with bot.conversation(chat, timeout=60) as conv:
				await event.respond('**📥 Input ID File Backup :**')
				msg_id = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				backup_id = msg_id.raw_text.strip()

				# 2. Proses Download dari Google Drive menggunakan gdown
				status_msg = await event.respond("`⏳ Downloading backup.zip ...`")
				
				# Pastikan folder /root ada atau hapus backup.zip lama jika ada
				if os.path.exists("/root/backup.zip"):
					os.remove("/root/backup.zip")

				dl_cmd = f'gdown "{backup_id}" -O /root/backup.zip'
				dl_result = subprocess.run(dl_cmd, shell=True, capture_output=True, text=True)

				# Cek apakah file terdownload dengan sukses
				if not os.path.exists("/root/backup.zip") or os.path.getsize("/root/backup.zip") == 0:
					await status_msg.edit("❌ **Gagal mendownload backup! ID file tidak valid atau file tidak ditemukan.**")
					return

				# 3. Minta Password Backup dari user
				await status_msg.edit("✅ **Download Selesai!**\n🔑 **Input Password Backup:**")
				msg_pass = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				backup_pw = msg_pass.raw_text.strip()

				# 4. Eksekusi Restore dengan Password
				await status_msg.edit("`⚙️ Processing Restore Data VPS...`")
				
				# Mengirimkan password ke perintah restore via pipeline
				restore_cmd = f'restore "{backup_pw}"'
				
				process = subprocess.run(restore_cmd, shell=True, capture_output=True, text=True)
				output = process.stdout if process.stdout else process.stderr

				# Hapus file zip temp setelah restore selesai
				if os.path.exists("/root/backup.zip"):
					os.remove("/root/backup.zip")

				msg = f"""
**✅ Restore Data Selesai!**
**🤖 @newbie_store242**
"""
				await event.respond(msg)

		except asyncio.TimeoutError:
			await event.respond("⚠️ **Waktu input habis (Timeout). Silakan ulangi lagi.**")
		except Exception as e:
			await event.respond(f"❌ **Terjadi Error:** `{str(e)}`")

	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await restore_(event)
	else:
		await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'backer'))
async def backers(event):
	async def backers_(event):
		inline = [
[Button.inline(" BACKUP","backup"),
Button.inline(" RESTORE","restore")],
[Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🐾🕊️ PREMIUM PANEL MENU 🕊️🐾**
━━━━━━━━━━━━━━━━━━━━━━━ 
🔰 **» Hostname/IP:** `{DOMAIN}`
🔰 **» ISP:** `{z["isp"]}`
🔰 **» Country:** `{z["country"]}`
🤖 **»@newbie_store242**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await backers_(event)
	else:
		await event.answer("Access Denied",alert=True)


@bot.on(events.CallbackQuery(data=b'setting'))
async def settings(event):
	async def settings_(event):
		inline = [
[Button.inline(" SPEEDTEST","speedtest"),
Button.inline(" BACKUP & RESTORE","backer")],
[Button.inline(" REBOOT SERVER","reboot"),
Button.inline(" RESTART SERVICE","resx")],
[Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🐾🕊️ PREMIUM PANEL MENU 🕊️🐾**
━━━━━━━━━━━━━━━━━━━━━━━ 
🔰 **» Hostname/IP:** `{DOMAIN}`
🔰 **» ISP:** `{z["isp"]}`
🔰 **» Country:** `{z["country"]}`
🤖 **»@newbie_store242**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await settings_(event)
	else:
		await event.answer("Access Denied",alert=True)
