import html
import requests
import subprocess
from telethon import events, Button
from kyt import bot, valid

NODE_API_URL = "http://id.nevpn.my.id:3005/api"

# Memory untuk menandai user yang sedang dalam sesi input setnote
AWAITING_NOTE = {}


# =========================================================
# 1. UTAMA: MENU ADMIN PANEL (DENGAN TOMBOL SET NOTE HC)
# =========================================================
@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline(" SSH OVPN MANAGER ", "ssh")],
        [Button.inline(" VMESS MANAGER ", "vmess"), Button.inline(" VLESS MANAGER ", "vless")],
        [Button.inline(" TROJAN MANAGER ", "trojan"), Button.inline(" SHDWSK MANAGER ", "shadowsocks")],
        [Button.inline(" 📝 SET NOTE HC ", "hc_note_menu")],  # 🟢 TOMBOL BARU MANAJEMEN NOTE
        [Button.inline(" CHECK VPS INFO ", "info"), Button.inline(" OTHER SETTING ", "setting")],
        [Button.inline(" ‹ Back Menu › ", "start")]
    ]
    
    sender = await event.get_sender()
    val = valid(str(sender.id))
    if val == "false":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except:
            await event.reply("Akses Ditolak")
    elif val == "true":
        sh = f' cat /etc/passwd | grep "home" | grep "false" | wc -l'
        ssh = subprocess.check_output(sh, shell=True).decode("ascii")
        vm = 'cat /etc/xray/config.json | grep "###" | wc -l'
        vms_count = int(subprocess.check_output(vm, shell=True).decode("ascii").strip())
        vms = int(vms_count / 2)
        vl = 'cat /etc/xray/config.json | grep "#&" | wc -l'
        vls_count = int(subprocess.check_output(vl, shell=True).decode("ascii").strip())
        vls = int(vls_count / 2)
        tr = 'cat /etc/xray/config.json | grep "#!" | wc -l'
        trj_count = int(subprocess.check_output(tr, shell=True).decode("ascii").strip())
        trj = int(trj_count / 2)
        sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
        namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
        ipvps = f" cat /usr/bin/.ipvps"
        ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
        citsy = f" cat /etc/xray/city"
        city = subprocess.check_output(citsy, shell=True).decode("ascii")
        domy = f" cat /etc/xray/domain"
        domain = subprocess.check_output(domy, shell=True).decode("ascii")

        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🐾🕊️ ADMIN PANEL MENU 🕊️🐾**
━━━━━━━━━━━━━━━━━━━━━━━ 
**» OS     :** `{namaos.strip().replace('"','')}`
**» CITY   :** `{city.strip()}`
**» DOMAIN :** `{domain.strip()}`
**» IP VPS :** `{ipsaya.strip()}`
**» Total Account Created:** 

**» 🚀SSH OVPN    :** `{ssh.strip()}` __account__
**» 🎭XRAY VMESS  :** `{vms}` __account__
**» 🗼XRAY VLESS  :** `{vls}` __account__
**» 🎯XRAY TROJAN :** `{trj}` __account__
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
        x = await event.edit(msg, buttons=inline)
        if not x:
            await event.reply(msg, buttons=inline)


# =========================================================
# 2. SUB-MENU NOTE HC (PREVIEW & UBAH NOTE)
# =========================================================
@bot.on(events.CallbackQuery(data=b'hc_note_menu'))
async def hc_note_menu(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) == "false":
        return await event.answer("Akses Ditolak", alert=True)

    inline = [
        [Button.inline("🔍 Preview Note Saat Ini", "preview_note")],
        [Button.inline("✏️ Ubah Note Config (.HC)", "change_note")],
        [Button.inline("‹ Kembali ke Menu", "menu")]
    ]

    msg = """
━━━━━━━━━━━━━━━━━━━━━━━
**📝 MANAJEMEN NOTE CONFIG (.HC)**
━━━━━━━━━━━━━━━━━━━━━━━
Silakan pilih aksi di bawah untuk melihat preview catatan saat ini atau memperbarui HTML Note khusus ID kamu:
"""
    await event.edit(msg, buttons=inline)


# =========================================================
# 3. HANDLER PREVIEW NOTE SAAT INI (Sama seperti /ceknote)
# =========================================================
@bot.on(events.CallbackQuery(data=b'preview_note'))
async def preview_note(event):
    sender = await event.get_sender()
    user_id = str(sender.id)

    if valid(user_id) == "false":
        return await event.answer("Akses Ditolak", alert=True)

    try:
        res = requests.get(f"{NODE_API_URL}/note/{user_id}", timeout=5).json()
        if res.get("status"):
            raw_note = res.get("note")
            safe_note = html.escape(raw_note)

            inline = [[Button.inline("‹ Kembali", "hc_note_menu")]]
            msg = f"🔍 <b>Preview Notes Kamu Saat Ini:</b>\n\n<pre>{safe_note}</pre>"
            
            await event.edit(msg, buttons=inline, parse_mode='html')
        else:
            await event.answer("❌ Gagal mengambil note dari Express API.", alert=True)
    except Exception as e:
        await event.answer(f"❌ Error: {str(e)}", alert=True)


# =========================================================
# 4. HANDLER INSTRUKSI UBAH NOTE (Sama seperti /setnote)
# =========================================================
@bot.on(events.CallbackQuery(data=b'change_note'))
async def change_note(event):
    sender = await event.get_sender()
    user_id = str(sender.id)

    if valid(user_id) == "false":
        return await event.answer("Akses Ditolak", alert=True)

    AWAITING_NOTE[user_id] = True

    msg = (
        "📝 <b>Pengaturan Notes Config (.HC)</b>\n\n"
        "Silakan kirim kode HTML notes yang baru dengan cara <b>REPLY / BALAS</b> pesan ini.\n\n"
        "<i>💡 Tips: Ketik <code>${remark}</code> di posisi tempat kamu ingin memunculkan teks remark secara otomatis.</i>"
    )
    await event.reply(msg, parse_mode='html')


# =========================================================
# 5. LISTENER REPLY TEKS DARI ADMIN UNTUK MENIMPAN NOTE
# =========================================================
@bot.on(events.NewMessage)
async def process_reply_note(event):
    if event.out or not event.text or event.text.startswith('/'):
        return

    sender = await event.get_sender()
    user_id = str(sender.id)

    if valid(user_id) == "false":
        return

    # Pengecekan apakah user membalas pesan instruksi bot
    reply_to = await event.get_reply_message()
    if reply_to and reply_to.sender and reply_to.sender.is_self:
        if "Pengaturan Notes Config (.HC)" in reply_to.text:
            new_note = event.raw_text.strip()

            try:
                res = requests.post(
                    f"{NODE_API_URL}/note",
                    json={"userId": user_id, "note": new_note},
                    timeout=5
                ).json()

                if res.get("status"):
                    if user_id in AWAITING_NOTE:
                        del AWAITING_NOTE[user_id]

                    msg = (
                        "✅ <b>Notes Config (.HC) Khusus ID Kamu Berhasil Diperbarui!</b>\n\n"
                        "Semua hasil generate file .hc selanjutnya akan otomatis menggunakan banner baru ini."
                    )
                    await event.reply(msg, parse_mode='html')
                else:
                    await event.reply(f"❌ Gagal menyimpan note: {res.get('error')}")

            except Exception as e:
                await event.reply(f"❌ Error koneksi ke Bridge API: {str(e)}")