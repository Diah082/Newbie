import base64
import os
import requests
from telethon import events, Button
from kyt import bot, valid
import asyncio

NODE_API_URL = "http://localhost:3005/api"
# Regex baru: Mendeteksi V2Ray (vmess/vless/trojan) ATAU format akun SSH (host:port@user:pass)
ACCOUNT_PATTERN = r"^(vless://|vmess://|trojan://|trojan-go://|[a-zA-Z0-9.-]+:\d+@[a-zA-Z0-9_.-]+:[a-zA-Z0-9_.-]+)"


# 1. Listener Auto-Detect Akun
@bot.on(events.NewMessage(pattern=ACCOUNT_PATTERN))
async def handle_account_input(event):
    if event.out or event.document:
        return

    sender = await event.get_sender()
    user_id = str(sender.id)

    if valid(user_id) == "false":
        return

    # PERBAIKAN: Gunakan event.raw_text agar format teks murni diambil tanpa diubah jadi link t.me
    raw_account = event.raw_text.strip()

    try:
        response = requests.post(
            f"{NODE_API_URL}/process-account", 
            json={"account": raw_account, "userId": user_id}, 
            timeout=10
        )
        
        if response.status_code != 200:
            return await event.reply(f"❌ **Bridge Error (HTTP {response.status_code}):**\n`{response.text[:200]}`")

        res = response.json()
        if not res.get("status"):
            return await event.reply(f"❌ Error: {res.get('error')}")

        buttons = []
        if res.get("mode") == "ssh":
            temp_row = []
            for item in res.get("templates", []):
                temp_row.append(Button.inline(item["title"], f"ssh_tpl_{item['key']}".encode('utf-8')))
                if len(temp_row) == 2:
                    buttons.append(temp_row)
                    temp_row = []
            if temp_row:
                buttons.append(temp_row)

        elif res.get("mode") == "v2ray":
            for btn in res.get("buttons", []):
                buttons.append([Button.inline(btn["title"], f"v2ray_act_{btn['action']}".encode('utf-8'))])

        # PERBAIKAN: Berikan parse_mode=None agar teks balasan tidak diolah ulang sebagai Markdown
        await event.reply(res.get("text"), buttons=buttons, parse_mode=None)

    except requests.exceptions.JSONDecodeError:
        await event.reply("❌ **Error:** Bridge Node.js mengembalikan respon non-JSON. Cek log Express.")
    except Exception as e:
        await event.reply(f"❌ **Gagal terhubung ke Bridge:** {str(e)}")

# 2. Callback Interaktif Bot
@bot.on(events.CallbackQuery)
async def handle_callbacks(event):
    data = event.data.decode('utf-8')
    sender = await event.get_sender()
    user_id = str(sender.id)

    # A. Aksi V2Ray
    if data.startswith('v2ray_act_'):
        action = data.replace('v2ray_act_', '')
        await event.edit("⏳ *Memuat daftar bug dari GitHub...*")

        try:
            res = requests.post(f"{NODE_API_URL}/get-v2ray-bugs", json={"userId": user_id, "action": action}, timeout=10).json()
            if not res.get("status"):
                return await event.edit("❌ Gagal memuat bug.")

            buttons = []
            temp_row = []
            for idx, bug in enumerate(res.get("bugs", [])):
                cb = f"apply_v2ray_{action}_{idx}".encode('utf-8')
                temp_row.append(Button.inline(bug["title"], cb))
                if len(temp_row) == 2:
                    buttons.append(temp_row)
                    temp_row = []
            if temp_row:
                buttons.append(temp_row)

            await event.edit(res.get("titleText"), buttons=buttons)
        except Exception as e:
            await event.edit(f"❌ Error: {str(e)}")

    # B. Eksekusi Bug Terpilih (Perbaikan Indexing Integer)
    elif data.startswith('apply_v2ray_'):
        parts = data.split('_')
        bug_index = int(parts[-1])
        action = "_".join(parts[2:-1])

        await event.edit("⏳ *Meresepkan Config & URI...*")

        try:
            res = requests.post(
                f"{NODE_API_URL}/apply-v2ray-bug", 
                json={"userId": user_id, "bugIndex": bug_index, "action": action},
                timeout=10
            ).json()

            if not res.get("status"):
                return await event.edit(f"❌ Gagal meracik bug: {res.get('error')}")

            buttons = []
            for btn in res.get("buttons", []):
                buttons.append([Button.inline(btn["title"], f"dl_file_{btn['appType']}".encode('utf-8'))])

            await event.edit(res.get("text"), buttons=buttons)
        except Exception as e:
            await event.edit(f"❌ Error: {str(e)}")

    # C. Eksekusi Template SSH
    elif data.startswith('ssh_tpl_'):
        tpl_key = data.replace('ssh_tpl_', '')
        await event.edit("⏳ *Menyiapkan template SSH...*")

        try:
            res = requests.post(f"{NODE_API_URL}/apply-ssh-template", json={"userId": user_id, "templateKey": tpl_key}, timeout=10).json()
            if not res.get("status"):
                return await event.edit("❌ Gagal memilih template.")

            buttons = []
            for btn in res.get("buttons", []):
                buttons.append([Button.inline(btn["title"], f"dl_file_{btn['appType']}".encode('utf-8'))])

            await event.edit(res.get("text"), buttons=buttons)
        except Exception as e:
            await event.edit(f"❌ Error: {str(e)}")

    elif data.startswith('dl_file_'):
        app_type = data.replace('dl_file_', '')
        status_msg = await event.reply("⏳ *Memproses dan meng-encode file config via Engine...*")

        try:
            res = requests.post(f"{NODE_API_URL}/generate-file", json={"userId": user_id, "appType": app_type}, timeout=30).json()
            if not res.get("status"):
                return await status_msg.edit(f"❌ *Gagal:* {res.get('error')}")

            file_name = res.get("fileName")
            file_bytes = base64.b64decode(res.get("fileData"))

            temp_path = f"/tmp/{file_name}"
            with open(temp_path, "wb") as f:
                f.write(file_bytes)

            # 1. Kirim file config ke Telegram
            await bot.send_file(
                event.chat_id,
                file=temp_path,
                caption=f"✅ File Config **{file_name}** berhasil dibuat!"
            )

            if os.path.exists(temp_path):
                os.remove(temp_path)

            await status_msg.delete()

            await asyncio.sleep(15)
            try:
                await event.delete()
            except Exception:
                pass # Abaikan jika pesan sudah dihapus manual oleh user

        except Exception as e:
            await status_msg.edit(f"❌ **Terjadi Kesalahan:** {str(e)}")