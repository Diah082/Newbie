# kyt/modules/hc_bridge.py
import requests

BRIDGE_URL = "http://localhost:3000/api"

def request_generate(params: dict):
    try:
        res = requests.post(f"{BRIDGE_URL}/generate", json=params, timeout=10)
        return res.json()
    except Exception as e:
        return {"status": False, "error": str(e)}

def request_decode(config_text: str):
    try:
        res = requests.post(f"{BRIDGE_URL}/decode", json={"config": config_text}, timeout=10)
        return res.json()
    except Exception as e:
        return {"status": False, "error": str(e)}

def request_get_note(user_id: str):
    try:
        res = requests.get(f"{BRIDGE_URL}/note/{user_id}", timeout=10)
        return res.json()
    except Exception as e:
        return {"status": False, "error": str(e)}

def request_set_note(user_id: str, note_text: str):
    try:
        res = requests.post(f"{BRIDGE_URL}/note", json={"userId": str(user_id), "note": note_text}, timeout=10)
        return res.json()
    except Exception as e:
        return {"status": False, "error": str(e)}